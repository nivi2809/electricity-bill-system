package electricity.biiling.system;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

public class Signup extends JFrame implements ActionListener {

Choice loginAsCho;
TextField meterText, EmployerText, userNameText, NameText,passwordText;
JButton create , back ;
    Signup(){
        super("Signup Page");
        getContentPane().setBackground(Color.pink);;

        JLabel createAs = new JLabel("Create Account As");
        createAs.setBounds(30, 50, 125, 20);
add(createAs);

loginAsCho = new Choice();
loginAsCho.add("Admin");
loginAsCho.add("Customer");
loginAsCho.setBounds(170, 50, 120, 20);
add(loginAsCho);

JLabel meterNo = new JLabel("Meter Number");
meterNo.setBounds(30, 100, 125, 20);
meterNo.setVisible(false);
add(meterNo);

meterText = new TextField();
meterText.setBounds(170, 100, 125, 20);
meterText.setVisible(false);
add(meterText);

JLabel Employer = new JLabel("Employee ID");
Employer.setBounds(30, 100, 125, 20);
Employer.setVisible(true);
add(Employer);

EmployerText = new TextField();
EmployerText.setBounds(170, 100, 125, 20);
EmployerText.setVisible(true);
add(EmployerText);


JLabel userName = new JLabel("User Name");
userName.setBounds(30, 140, 125, 20);
add(userName);

userNameText = new TextField();
userNameText.setBounds(170, 140, 125, 20);
add(userNameText);

JLabel Name = new JLabel("Name");
Name.setBounds(30, 180, 125, 20);
add(Name);

NameText = new TextField("");
NameText.setBounds(170, 180, 125, 20);
add(NameText);

meterText.addFocusListener(new FocusListener() {
    @Override
    public void focusGained(FocusEvent e) {
        try {

        }catch (Exception E){
            E.printStackTrace();
        }
    }

    @Override
    public void focusLost(FocusEvent e) {
        database c = new database();
        try {
            ResultSet resultSet = c.statement.executeQuery("select * from Signup where meter_no = '"+meterText.getText()+"'");
            if (resultSet.next()){
                NameText.setText(resultSet.getString("name"));
            }
        } catch (Exception E) {
            E.printStackTrace();
        }

    }
});

JLabel password = new JLabel("Password");
password.setBounds(30, 220, 125, 20);
add(password);

passwordText = new TextField();
passwordText.setBounds(170, 220, 125, 20);
add(passwordText);



loginAsCho.addItemListener(new ItemListener() {
    public void itemStateChanged(ItemEvent e){
        String user = loginAsCho.getSelectedItem();
        if ( user.equals("Customer")){
            Employer.setVisible(false);
            NameText.setEditable(false);
            EmployerText.setVisible(false);
            meterNo.setVisible(true);
            meterText.setVisible(true);
        } else{
            Employer.setVisible(true);
            EmployerText.setVisible(true);
            meterNo.setVisible(false);
            meterText.setVisible(false);
        }
    }
});

create = new JButton("Create");
create.setBackground(Color.lightGray);
create.setForeground(Color.red);
create.setBounds(50, 280, 100, 25);
create.addActionListener(this);
add(create);


back = new JButton("Back");
back.setBackground(Color.lightGray);
back.setForeground(Color.red);
back.setBounds(180, 280, 100, 25);
back.addActionListener(this);
add(back);

ImageIcon boyIcon = new ImageIcon(ClassLoader.getSystemResource("icon/boy.png"));//add image path
Image boyImage = boyIcon.getImage().getScaledInstance(250, 250, Image.SCALE_DEFAULT);
ImageIcon boyIcon2 = new ImageIcon(boyImage);
JLabel boyJLabel = new JLabel(boyIcon2);
boyJLabel.setBounds(320, 30, 250, 250);
add(boyJLabel);





setSize(600, 380);
setLocation(500, 200);
setLayout(null);
setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
    if (e.getSource()== create){
        String sloginAs = loginAsCho.getSelectedItem();
        String susername = userNameText.getText();
        String sname = NameText.getText();
        String spassword = passwordText.getText();
        String smeter = meterText.getText();
        try{
database c = new database();
String query = null;
if (loginAsCho.equals("Admin")) {
    query = " insert into Signup value('" + smeter + "', '" + susername + "', '" + sname + "', '" + spassword + "','" + sloginAs + "')";
} else {
    query = "update Signup set username = '"+susername+"', password = '" + spassword + "' , user_type = '" + sloginAs + "' where meter_no = '" + smeter + "'   ";
}
c.statement.executeUpdate(query);
            JOptionPane.showMessageDialog(null,"Account Created");
            setVisible(false);
            new Login();

        }catch(Exception E){
            E.printStackTrace();
        }

    } else if (e.getSource()==back) {
        setVisible(false);
        new Login();
        
    }
        
    }
public static void main(String[] args) {
   new Signup(); 
}
    
}