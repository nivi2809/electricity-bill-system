package electricity.biiling.system;

import java.sql.ResultSet;

import javax.swing.table.TableModel;

public class DbUtils {

    public static TableModel resultSetToTableModel(ResultSet resultSet) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'resultSetToTableModel'");
    }

}
