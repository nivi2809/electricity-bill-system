package electricity.biiling.system;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Splash extends JFrame{
  Splash(){

    ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource( "icon/splash/Splash.jpg"));//add image path
    Image imageOne = imageIcon.getImage().getScaledInstance(600, 400, Image.SCALE_DEFAULT);//size of image
    
    ImageIcon imageIcon2=new ImageIcon(imageOne);
    JLabel imageJLabel=new JLabel(imageIcon2);
    add(imageJLabel);//add image
    
setSize(600, 400);//size of frame
setLocation(500, 200);
setVisible(true);

try{
Thread.sleep(3000);//timer of frame
setVisible(false);

new Login();
}catch(Exception e){
  e.printStackTrace();
}
  }
  public static void main(String[] args) {
    new Splash();
  }
}