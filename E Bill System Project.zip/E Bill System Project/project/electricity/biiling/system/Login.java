package electricity.biiling.system;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.*;

public class Login extends JFrame implements ActionListener {
  JTextField usertext,passwordtext;
   Choice loginChoice;
JButton loginButton,cancleButton,signupButton;




  Login(){

    super("Login Page");//for give tiltle
getContentPane().setBackground(Color.lightGray);


    JLabel username = new JLabel("UserName");//Add text in frame
    username.setBounds(300, 60, 100, 20);
    add(username);

     usertext = new JTextField();//for add block
    usertext.setBounds(400, 60, 150, 20);
    add(usertext);


    JLabel password = new JLabel("Password");
    password.setBounds(300, 100, 100, 20);
    add(password);

     passwordtext = new JTextField();//for add block
    passwordtext .setBounds(400, 100, 150, 20);
    add(passwordtext);

    JLabel login = new JLabel("Login In As");
    login.setBounds(300, 140, 100,20);
    add(login);
     
    loginChoice = new Choice();//for enter choice
    loginChoice.add("Admin");
    loginChoice.add("Customer");
    loginChoice.setBounds(400, 140, 150, 20);
    add(loginChoice);

    loginButton = new JButton("Login");//generate buttons
    loginButton.setBounds(330, 180, 100, 20);
    loginButton.addActionListener(this);
    add(loginButton);

    cancleButton = new JButton("Cancle");//generate buttons
    cancleButton.setBounds(450, 180, 100, 20);
    cancleButton.addActionListener(this);
    add(cancleButton);
   
    signupButton = new JButton("Sign Up");//generate buttons
    signupButton.setBounds(390, 220, 100, 20);
    signupButton.addActionListener(this);
    add(signupButton);

   
    ImageIcon profileOne = new ImageIcon(ClassLoader.getSystemResource("icon/profile.png"));//add image path
    Image profileTwo = profileOne.getImage().getScaledInstance(230, 230,Image.SCALE_DEFAULT);// size of image
    ImageIcon fprofileOne = new ImageIcon(profileTwo);
    JLabel profileLabel = new JLabel(fprofileOne);
    profileLabel.setBounds(10, 10,230, 230);
    add(profileLabel);

  

    setSize(640, 300);//size of frame
    setLocation(400, 200);//location of frame
    setLayout(null);
setVisible(true);//for visibility
  }
  @Override
  public void actionPerformed(ActionEvent e){/*add the action on buttons */
    if(e.getSource()==loginButton) {
      String susername = usertext.getText();
        String spassword = passwordtext.getText();
        String suser = loginChoice.getSelectedItem();

        try {
            database c = new database();
                String query = "select * from Signup where username = '"+susername+"' and password = '"+spassword+"' and  user_type = '"+suser+"' ";
            ResultSet resultSet =  c.statement.executeQuery(query);

            if (resultSet.next()){
                String meter = resultSet.getString("meter_no");
                setVisible(false);
                new main_class(suser,meter);
            }else {
                JOptionPane.showMessageDialog(null,"Invalid Login");
            }



        }catch (Exception E){
            E.printStackTrace();
        }


      
    } else if (e.getSource()==cancleButton) {
      setVisible(false);  
    } else if (e.getSource()==signupButton) {
      setVisible(false);
      new Signup();
      
    }

  }
  public static void main(String[] args) {

      new Login();
  }  
  }




